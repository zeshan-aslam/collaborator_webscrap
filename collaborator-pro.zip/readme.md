Steps To Run:--

1. Download Node.exe from google in your local
2. Clone this Repo
3. In terminal write command:- "npm instal"
4. Then go to file index.js in run the file with the code Runner extension
   
